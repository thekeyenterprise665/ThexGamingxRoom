/*
GameAuthorizer.java 

KEYNEISHA D. MCNEALEY 

PROFESSOR HECKER 

07/23/2024 
*/
//The authenticate method in GameAuthenticator has been successfully completed by creating a 
//new instance of GameUser with the authenticated username and roles.
package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;

public class GameAuthorizer implements Authorizer<GameUser> {

    @Override
    public boolean authorize(GameUser user, String role) {
        return user.getRoles().contains(role);
    }
}