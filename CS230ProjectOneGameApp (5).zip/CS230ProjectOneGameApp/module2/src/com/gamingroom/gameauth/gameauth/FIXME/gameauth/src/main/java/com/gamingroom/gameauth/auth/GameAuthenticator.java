/*
GameAuthenticator.java 

KEYNEISHA D. MCNEALEY 

PROFESSOR HECKER 

07/23/2024 
*/

//rewrite in a [firm], [kind] and [passionate] tone: I have also completed the authorize method in GameAuthorizer by checking if the user's roles contain the required role.
package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;

public class GameAuthenticator implements Authenticator<BasicCredentials, GameUser> {

    private static final Map<String, Set<String>> VALID_USERS = ImmutableMap.of(
        "guest", ImmutableSet.of(),
        "user", ImmutableSet.of("USER"),
        "admin", ImmutableSet.of("ADMIN", "USER")
    );

    @Override
    public Optional<GameUser> authenticate(BasicCredentials credentials) throws AuthenticationException {
        if (VALID_USERS.containsKey(credentials.getUsername()) && "password".equals(credentials.getPassword())) {
            Set<String> roles = VALID_USERS.get(credentials.getUsername());
            GameUser user = new GameUser(credentials.getUsername(), roles);
            return Optional.of(user);
        }
        return Optional.empty();
    }
}