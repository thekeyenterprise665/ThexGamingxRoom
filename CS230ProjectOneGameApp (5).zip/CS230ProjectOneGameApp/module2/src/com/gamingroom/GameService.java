
/*
ProjectOne.cpp 

KEYNEISHA D. MCNEALEY 

PROFESSOR HECKER 

07/23/2024 
*/

import java.util.ArrayList;
import java.util.List;

public class GameService {
    private static GameService instance;
    private static int nextGameId = 1;
    private static int nextTeamId = 1;
    private static int nextPlayerId = 1;
    private List<Game> games;

    private GameService() {
        games = new ArrayList<>();
    }

    public static synchronized GameService getInstance() {
        if (instance == null) {
            instance = new GameService();
        }
        return instance;
    }

    public Game addGame(String name) {
        String id = "game" + nextGameId++;
        Game game = new Game(id, name);
        games.add(game);
        return game;
    }

    public Game getGame(String id) {
        for (Game game : games) {
            if (game.getId().equals(id)) {
                return game;
            }
        }
        return null;
    }

    public boolean isGameNameUnique(String name) {
        for (Game game : games) {
            if (game.getName().equals(name)) {
                return false;
            }
        }
        return true;
    }

    public boolean isTeamNameUnique(Game game, String name) {
        for (Team team : game.getTeams()) {
            if (team.getName().equals(name)) {
                return false;
            }
        }
        return true;
    }
}

