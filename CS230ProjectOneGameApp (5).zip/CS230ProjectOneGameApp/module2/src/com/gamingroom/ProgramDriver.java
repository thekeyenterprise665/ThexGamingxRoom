/*
ProjectOne.cpp 

KEYNEISHA D. MCNEALEY 

PROFESSOR HECKER 

07/23/2024 
*/


public class ProgramDriver {
    public static void main(String[] args) {
        GameService gameService = GameService.getInstance();
        Game game1 = gameService.addGame("Draw It or Lose It");
        Team team1 = new Team("team1", "Team A");
        Player player1 = new Player("player1", "Alice");
        team1.addPlayer(player1);
        game1.addTeam(team1);
        System.out.println("Game: " + game1.getName());
        System.out.println("Team: " + team1.getName());
        System.out.println("Player: " + player1.getName());
    }
}