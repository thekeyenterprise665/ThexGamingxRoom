
/*
ProjectOne.cpp 

KEYNEISHA D. MCNEALEY 

PROFESSOR HECKER 

07/23/2024 
*/

package com.gamingroom;
public class SingletonTester {

	public void testSingleton() {
		
		System.out.println("\nAbout to test the singleton...");
		
		// Obtain local reference to the singleton instance
		GameService service1 = GameService.getInstance();
		
		// Add some games to the service
		service1.addGame(new Game("Game 1"));
		service1.addGame(new Game("Game 2"));
		service1.addGame(new Game("Game 3"));
		
		// a simple for loop to print the games
		for (int i = 0; i < service1.getGameCount(); i++) {
			System.out.println(service1.getGame(i));
		}

		// Test if the singleton instance is the same
		GameService service2 = GameService.getInstance();
		if (service1 == service2) {
			System.out.println("Singleton pattern works! Both instances are the same.");
		} else {
			System.out.println("Singleton pattern failed! Instances are different.");
		}
	}
	
}
