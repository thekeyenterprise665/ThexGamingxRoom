package com.three19;

public class TwoWheeled extends Vehicle {
}
